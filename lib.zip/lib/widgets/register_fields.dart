import 'package:flutter/material.dart';

import 'app_select_field.dart';

class AvailabilityField extends StatelessWidget {
  const AvailabilityField({super.key, required this.days, required this.onTap});

  final Set<String> days;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    const labels = ['M', 'T', 'W', 'Th', 'F', 'S', 'S'];
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFD8D8D8)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Expanded(
              child: Text(
                'Availability',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ),
            for (final label in labels)
              Container(
                width: 20,
                height: 20,
                margin: const EdgeInsets.only(left: 4),
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  color: Color(0x885A4034),
                  shape: BoxShape.circle,
                ),
                child: Text(
                  label,
                  style: const TextStyle(color: Colors.white, fontSize: 9),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class CourtField extends StatelessWidget {
  const CourtField({super.key, required this.value, required this.onChanged});

  final String? value;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) => AppSelectField<String>(
    label: 'Court of practice',
    hint: 'Select court of practice',
    value: value,
    options: const ['Supreme Court', 'High Court', 'District Court'],
    itemLabel: (court) => court,
    onChanged: onChanged,
    validator: (selected) => selected == null ? 'Required' : null,
  );
}
