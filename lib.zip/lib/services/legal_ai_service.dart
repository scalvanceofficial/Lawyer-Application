import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;

class LegalAiService {
  LegalAiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  final List<Map<String, dynamic>> _history = [];

  static const _systemInstruction =
      'You are Aapke Lawyer AI, a legal information assistant. '
      'Answer only legal or closely related procedural questions. '
      'Use plain language, short paragraphs, and numbered steps where helpful. '
      'Ask for the country/state when jurisdiction matters. Never claim to be '
      'the user’s lawyer, never guarantee outcomes, and clearly distinguish '
      'general legal information from advice. For urgent arrest, violence, '
      'self-harm, or immediate danger, tell the user to contact appropriate '
      'local emergency services or a qualified lawyer immediately. Do not '
      'invent statutes, cases, citations, deadlines, or court procedures. If '
      'uncertain, say so and recommend verification with a qualified lawyer.';

  static final RegExp _legalTerms = RegExp(
    r'\b('
    r'law|legal|lawyer|advocate|attorney|court|judge|judgment|petition|'
    r'appeal|case|lawsuit|litigation|notice|summons|warrant|contract|'
    r'agreement|clause|breach|rights?|crime|criminal|civil|police|fir|'
    r'bail|arrest|custody|divorce|marriage|maintenance|alimony|domestic '
    r'violence|property|tenant|landlord|rent|lease|inheritance|succession|'
    r'will and testament|probate|consumer|fraud|cheating|cybercrime|harassment|defamation|'
    r'copyright|trademark|patent|company|employment|labour|labor|salary|'
    r'tax|gst|ipc|crpc|bnss|bns|evidence act|constitution|supreme court|'
    r'high court|district court|tribunal|affidavit|notary|registration|'
    r'compensation|damages|injunction|limitation|mediation|arbitration|'
    r'plaintiff|defendant|jurisdiction|tort|precedent|statute|negligence|'
    r'liability|settlement|pleading|discovery|motion|verdict|sentencing|'
    r'deposition|hearing|probation|parole|pardon|acquittal|conviction|'
    r'magistrate|prosecutor|legal aid|charge sheet|cpc|indian penal code|'
    r'indian contract act|companies act|consumer protection act|factories act|'
    r'transfer of property act|power of attorney|sale deed|lease agreement|'
    r'divorce petition|child custody|court order|legal notice|dowry|adoption|'
    r'fiduciary duty|professional misconduct|legal malpractice|income tax|'
    r'corporate governance|data protection|compliance|constitutional law|'
    r'administrative law|family law|corporate law|tax law|immigration law|'
    r'environmental law|real estate|international law|cyber law|due process|'
    r'indemnity|force majeure|non-disclosure agreement|nda|mou|memorandum of '
    r'understanding|terms and conditions|indemnification|burden of proof|'
    r'plea bargain|legal counsel|specific performance|class action|legal brief'
    r')\b',
    caseSensitive: false,
  );

  static bool isLegalQuery(String text, {bool hasLegalContext = false}) {
    final normalized = text.trim();
    if (normalized.length < 3) return false;
    return _legalTerms.hasMatch(normalized) ||
        (hasLegalContext && normalized.split(RegExp(r'\s+')).length >= 2);
  }

  Future<String> send(String message) async {
    try {
      final keySnapshot = await FirebaseFirestore.instance
          .collection('usefulkey')
          .limit(1)
          .get();
      if (keySnapshot.docs.isEmpty) {
        throw const LegalAiException(
          'AI key is missing. Add an openaikey field to the usefulkey collection.',
        );
      }
      final keyData = keySnapshot.docs.first.data();
      final apiKey = (keyData['openaikey'] ?? '').toString().trim();
      final model = (keyData['model'] ?? 'gemini-2.0-flash').toString().trim();
      if (apiKey.isEmpty) {
        throw const LegalAiException(
          'The openaikey field in Firestore is empty.',
        );
      }

      final userContent = {
        'role': 'user',
        'parts': [
          {'text': message.trim()},
        ],
      };
      final uri = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/'
        '${Uri.encodeComponent(model)}:generateContent',
      );
      late http.Response response;
      for (var attempt = 0; attempt < 3; attempt++) {
        response = await _client.post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': apiKey,
          },
          body: jsonEncode({
            'system_instruction': {
              'parts': [
                {'text': _systemInstruction},
              ],
            },
            'contents': [..._history, userContent],
          }),
        );
        if (response.statusCode != 429 || attempt == 2) break;
        await Future<void>.delayed(Duration(seconds: 1 << (attempt + 1)));
      }
      final payload = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 200) {
        final apiMessage =
            ((payload['error'] as Map?)?['message'] ?? 'Unknown Gemini error')
                .toString();
        final safeApiMessage = _redactSecrets(apiMessage, apiKey);
        final explanation = switch (response.statusCode) {
          400 => 'Gemini rejected the request: $safeApiMessage',
          403 when apiMessage.toLowerCase().contains('suspended') =>
            'The Gemini API key has been suspended by Google. Chat cannot '
                'work with this key. Create a new Gemini key, enable the '
                'Generative Language API, and replace the openaikey value in '
                'Firestore.',
          403 =>
            'Google rejected the Gemini API key. Check that the key is active, '
                'the Generative Language API is enabled, and its restrictions '
                'allow Gemini. Details: $safeApiMessage',
          404 => 'The Gemini model "$model" is unavailable: $safeApiMessage',
          429 => 'The Gemini usage limit was reached. Please try again later.',
          _ => 'Gemini returned error ${response.statusCode}: $safeApiMessage',
        };
        throw LegalAiException(explanation);
      }

      final candidates = payload['candidates'] as List?;
      final content = candidates?.firstOrNull as Map?;
      final modelContent = content?['content'] as Map?;
      final parts = modelContent?['parts'] as List?;
      final text = parts
          ?.whereType<Map>()
          .map((part) => part['text']?.toString() ?? '')
          .join()
          .trim();
      if (text == null || text.isEmpty) {
        throw const LegalAiException(
          'The assistant returned an empty answer. Please ask again.',
        );
      }
      _history
        ..add(userContent)
        ..add({
          'role': 'model',
          'parts': [
            {'text': text},
          ],
        });
      return _format(text);
    } on LegalAiException {
      rethrow;
    } on FirebaseException catch (error) {
      throw LegalAiException(
        error.code == 'permission-denied'
            ? 'Firestore denied access to usefulkey. Deploy the updated '
                  'Firestore rules and try again.'
            : 'Could not read the AI configuration: ${error.message ?? error.code}',
      );
    } on FormatException {
      throw const LegalAiException(
        'Gemini returned an unreadable response. Please try again.',
      );
    } catch (_) {
      throw const LegalAiException(
        'Could not reach Gemini. Check your internet connection and try again.',
      );
    }
  }

  static String _format(String text) {
    return text
        .replaceAll('**', '')
        .replaceAll(RegExp(r'^\s*[\*\-]\s+', multiLine: true), '• ')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
  }

  static String _redactSecrets(String message, String apiKey) {
    var safe = message.replaceAll(apiKey, '[API key hidden]');
    safe = safe.replaceAll(
      RegExp(r'AIza[0-9A-Za-z_-]{20,}'),
      '[API key hidden]',
    );
    return safe;
  }
}

class LegalAiException implements Exception {
  const LegalAiException(this.message);
  final String message;
}
