import 'package:flutter/material.dart';

import '../models/subscription_plan.dart';
import '../models/user_profile.dart';
import '../models/user_role.dart';
import '../services/subscription_service.dart';
import '../theme/app_colors.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({
    super.key,
    required this.role,
    required this.profile,
    this.embedded = false,
  });

  final UserRole role;
  final UserProfile profile;
  final bool embedded;

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  String? _processingPlan;
  late Future<SubscriptionAccess> _access;

  @override
  void initState() {
    super.initState();
    _access = SubscriptionService.access(widget.role);
  }

  Future<void> _subscribe(SubscriptionPlan plan) async {
    if (_processingPlan != null) return;
    setState(() => _processingPlan = plan.documentId);
    try {
      final access = await SubscriptionService.subscribe(
        plan: plan,
        role: widget.role,
        name: widget.profile.name,
        email: widget.profile.email,
        phone: widget.profile.phone,
      );
      if (!mounted) return;
      setState(() => _access = Future.value(access));
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Subscription active until ${_dateLabel(access.endDate!)}.',
          ),
          backgroundColor: Colors.green.shade700,
        ),
      );
      if (!widget.embedded && Navigator.of(context).canPop()) {
        Navigator.of(context).pop(true);
      }
    } on SubscriptionActivationException catch (error) {
      await _showActivationProblem(error);
    } on SubscriptionException catch (error) {
      _showError(error.message);
    } catch (error) {
      _showError(
        'Something unexpected stopped before activation. '
        'No plan was created. Please try again or contact support.',
      );
    } finally {
      if (mounted) setState(() => _processingPlan = null);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _showActivationProblem(
    SubscriptionActivationException error,
  ) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded, color: Colors.orange),
        title: const Text('Payment received, activation needs help'),
        content: SelectableText(
          '${error.message}\n\nPayment ID: ${error.paymentId}',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('I saved the payment ID'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final content = RefreshIndicator(
      onRefresh: () async {
        setState(() => _access = SubscriptionService.access(widget.role));
        await _access;
      },
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(22),
        children: [
          const Text(
            'Choose your access plan',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 7),
          const Text(
            'Your first month is free as a lawyer. After that, choose a '
            'Firestore plan to keep using the AI tools.',
            style: TextStyle(color: kHint),
          ),
          const SizedBox(height: 18),
          FutureBuilder<SubscriptionAccess>(
            future: _access,
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const SizedBox.shrink();
              return _AccessBanner(access: snapshot.data!);
            },
          ),
          const SizedBox(height: 18),
          StreamBuilder<List<SubscriptionPlan>>(
            stream: SubscriptionService.plans(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return _MessageCard(
                  icon: Icons.cloud_off_outlined,
                  title: 'Could not load plans',
                  message:
                      'Check your connection and Firestore rules, then pull down to retry.',
                );
              }
              if (!snapshot.hasData) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(36),
                    child: CircularProgressIndicator(),
                  ),
                );
              }
              if (snapshot.data!.isEmpty) {
                return const _MessageCard(
                  icon: Icons.inventory_2_outlined,
                  title: 'No plans available',
                  message:
                      'Add active plans with a valid price to the Firestore plans collection.',
                );
              }
              return Column(
                children: [
                  for (final plan in snapshot.data!) ...[
                    _PlanCard(
                      plan: plan,
                      processing: _processingPlan == plan.documentId,
                      disabled: _processingPlan != null,
                      onChoose: () => _subscribe(plan),
                    ),
                    const SizedBox(height: 14),
                  ],
                ],
              );
            },
          ),
        ],
      ),
    );

    if (widget.embedded) return content;
    return Scaffold(
      appBar: AppBar(title: const Text('Subscription')),
      body: SafeArea(child: content),
    );
  }
}

class _AccessBanner extends StatelessWidget {
  const _AccessBanner({required this.access});
  final SubscriptionAccess access;

  @override
  Widget build(BuildContext context) {
    final trial = access.source == SubscriptionAccessSource.lawyerTrial;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: access.isActive
            ? const Color(0xFFE8F5E9)
            : const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            access.isActive ? Icons.verified_outlined : Icons.info_outline,
            color: access.isActive ? Colors.green.shade700 : Colors.orange,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: trial
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your first month is free until ${_dateLabel(access.endDate!)}',
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 7),
                      const Text(
                        'You can use AI Chat Bot, AI Court and Legal Resources '
                        'now—no payment is needed during this free month.',
                      ),
                      const SizedBox(height: 7),
                      const Text(
                        'After this date, AI access will be locked until you '
                        'buy a plan. If you buy early, your paid plan starts '
                        'after the free month, so you lose no free days.',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ],
                  )
                : Text(
                    access.isActive
                        ? 'Your paid subscription is active until ${_dateLabel(access.endDate!)}.'
                        : access.message!,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
          ),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({
    required this.plan,
    required this.processing,
    required this.disabled,
    required this.onChoose,
  });

  final SubscriptionPlan plan;
  final bool processing;
  final bool disabled;
  final VoidCallback onChoose;

  @override
  Widget build(BuildContext context) => Card(
    elevation: plan.popular ? 5 : 1,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: BorderSide(
        color: plan.popular ? kBrown : const Color(0xFFE4D8CE),
        width: plan.popular ? 2 : 1,
      ),
    ),
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (plan.popular)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: kBrown,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'POPULAR',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                ),
              ),
            ),
          if (plan.popular) const SizedBox(height: 12),
          Text(
            plan.duration,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            '₹${plan.price}',
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w900,
              color: kBrown,
            ),
          ),
          if (plan.discount > 0)
            Text(
              '${plan.discount}% discount included',
              style: const TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.w700,
              ),
            ),
          const SizedBox(height: 14),
          for (final feature in plan.features)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.green, size: 20),
                  const SizedBox(width: 9),
                  Expanded(child: Text(feature)),
                ],
              ),
            ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: disabled ? null : onChoose,
              child: Text(processing ? 'Opening payment…' : 'Choose plan'),
            ),
          ),
        ],
      ),
    ),
  );
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({
    required this.icon,
    required this.title,
    required this.message,
  });
  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Icon(icon, size: 42, color: kBrown),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          Text(message, textAlign: TextAlign.center),
        ],
      ),
    ),
  );
}

String _dateLabel(DateTime date) {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}
