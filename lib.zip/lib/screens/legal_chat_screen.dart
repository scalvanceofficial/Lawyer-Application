import 'package:flutter/material.dart';

import '../services/legal_ai_service.dart';
import '../theme/app_colors.dart';

class LegalChatScreen extends StatefulWidget {
  const LegalChatScreen({super.key});

  @override
  State<LegalChatScreen> createState() => _LegalChatScreenState();
}

class _LegalChatScreenState extends State<LegalChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _focusNode = FocusNode();
  final _ai = LegalAiService();
  final List<_ChatMessage> _messages = const [
    _ChatMessage(
      text:
          'Hello! Ask me a legal question. I provide general legal information, not a substitute for advice from your lawyer.',
      fromUser: false,
    ),
  ].toList();
  bool _sending = false;
  bool _hasLegalContext = false;

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;
    _controller.clear();
    setState(() => _messages.add(_ChatMessage(text: text, fromUser: true)));
    _scrollToBottom();

    if (!LegalAiService.isLegalQuery(text, hasLegalContext: _hasLegalContext)) {
      setState(
        () => _messages.add(
          const _ChatMessage(
            text:
                'This assistant is only for legal questions. Please ask about matters such as rights, court procedure, contracts, property, family law, FIR, bail, employment, or another legal issue.',
            fromUser: false,
          ),
        ),
      );
      _scrollToBottom();
      _focusNode.requestFocus();
      return;
    }

    _hasLegalContext = true;
    setState(() => _sending = true);
    try {
      final answer = await _ai.send(text);
      if (!mounted) return;
      setState(
        () => _messages.add(_ChatMessage(text: answer, fromUser: false)),
      );
    } on LegalAiException catch (error) {
      if (!mounted) return;
      setState(
        () => _messages.add(
          _ChatMessage(text: error.message, fromUser: false, isError: true),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _sending = false);
        _scrollToBottom();
        _focusNode.requestFocus();
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Container(
        width: double.infinity,
        color: const Color(0xFFFFF3E8),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        child: const Text(
          'AI can make mistakes. Verify important information with a qualified lawyer.',
          textAlign: TextAlign.center,
          style: TextStyle(color: kBrown, fontWeight: FontWeight.w700),
        ),
      ),
      Expanded(
        child: ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
          itemCount: _messages.length + (_sending ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == _messages.length) {
              return const _TypingIndicator();
            }
            return _MessageBubble(message: _messages[index]);
          },
        ),
      ),
      SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  minLines: 1,
                  maxLines: 4,
                  textCapitalization: TextCapitalization.sentences,
                  textInputAction: TextInputAction.newline,
                  decoration: InputDecoration(
                    hintText: 'Ask a legal question…',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 9),
              IconButton.filled(
                onPressed: _sending ? null : _send,
                icon: const Icon(Icons.send),
                tooltip: 'Send question',
              ),
            ],
          ),
        ),
      ),
    ],
  );
}

class _ChatMessage {
  const _ChatMessage({
    required this.text,
    required this.fromUser,
    this.isError = false,
  });
  final String text;
  final bool fromUser;
  final bool isError;
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message});
  final _ChatMessage message;

  @override
  Widget build(BuildContext context) => Align(
    alignment: message.fromUser ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      constraints: const BoxConstraints(maxWidth: 620),
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
      decoration: BoxDecoration(
        color: message.fromUser
            ? kBrown
            : message.isError
            ? const Color(0xFFFFE8E8)
            : Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: SelectableText(
        message.fromUser ? message.text : 'LawBot\n${message.text}',
        style: TextStyle(
          color: message.fromUser ? Colors.white : Colors.black87,
          height: 1.4,
          fontWeight: message.fromUser ? FontWeight.normal : FontWeight.w500,
        ),
      ),
    ),
  );
}

class _TypingIndicator extends StatelessWidget {
  const _TypingIndicator();

  @override
  Widget build(BuildContext context) => const Align(
    alignment: Alignment.centerLeft,
    child: Padding(
      padding: EdgeInsets.only(left: 8, bottom: 14),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          SizedBox(width: 9),
          Text('Preparing a legal response…'),
        ],
      ),
    ),
  );
}
