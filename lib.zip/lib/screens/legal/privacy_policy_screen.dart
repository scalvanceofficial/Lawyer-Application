import 'package:flutter/material.dart';

import 'legal_policy_page.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const LegalPolicyPage(
      title: 'Privacy Policy',
      introduction:
          'At AAPKE LAWYER, we are committed to protecting your privacy and the security of your personal information. This policy explains how we collect, use, disclose, and protect information provided while using our platform.',
      sections: [
        LegalSection('1. Information We Collect', [
          'We may collect information provided by lawyers during registration, including name, email address, contact number, experience, Bar Council ID, areas of expertise, and courts of practice.',
          'We may collect information provided by clients during registration, including name, email address, contact number, date of birth, and sex.',
          'We may collect case details and preferences submitted by clients when requesting legal services, along with information collected automatically through cookies and similar technologies.',
        ]),
        LegalSection('2. Use of Information', [
          'We use information to provide and improve our services, match clients with suitable lawyers, facilitate communication, personalize the user experience, process payments, and communicate service updates or relevant promotions.',
        ]),
        LegalSection('3. Disclosure of Information', [
          'We may share necessary information with lawyers or legal professionals to facilitate legal services; with service providers supporting platform operations, payments, or service delivery; and with authorities when required by law or necessary to protect our rights and interests.',
        ]),
        LegalSection('4. Payment and Fees', [
          'Lawyers and clients are required to make applicable payments for use of the platform. Registration, platform, or booking fees are non-refundable and cover access to and use of our services.',
        ]),
        LegalSection('5. Data Security', [
          'We use appropriate safeguards, including industry-standard security measures, to help prevent unauthorized access, disclosure, alteration, or destruction of personal information.',
        ]),
        LegalSection('6. Changes to This Policy', [
          'We may modify this Privacy Policy at any time. Material changes may be announced on the platform or by email. Continued use after a change constitutes acceptance of the revised policy.',
        ]),
        LegalSection('7. Contact Us', [
          'Questions or concerns about this policy may be sent to:',
          'Address: Pune, Maharashtra\nPhone: 90042 97172, 90040 87172\nEmail: aapkelawyer@gmail.com\nWorking hours: 24 hours',
          'By using AAPKE LAWYER, you acknowledge that you have read, understood, and agree to be bound by this Privacy Policy.',
        ]),
        LegalSection('Refund & Cancellation Policy', [
          'The ₹249 advocate registration fee and ₹149 client platform fee are non-refundable. Once payment is successfully processed, no refund will be issued.',
          'A confirmation invoice will be sent to the email address supplied during registration or payment. Because services are rendered upon payment, cancellation is not applicable after payment and delivery of access.',
        ]),
        LegalSection('Shipping Policy', [
          'All AAPKE LAWYER services are digital. Services are made available after successful payment, and relevant documents such as invoices are delivered by email.',
          'Advocates receive listing access after payment of the registration fee. Clients receive advocate contact details after payment of the platform fee.',
          'Confirmation and access are normally provided immediately after a successful transaction. For assistance, contact aapkelawyer@gmail.com or call 90040 87172 / 90042 97172.',
        ]),
        LegalSection('Pricing Policy', [
          'Advocates pay ₹249 as a registration amount. Clients pay ₹149 as a platform fee.',
          'The client pays the platform fee only after an advocate accepts the case request. If a client pays one advocate and then pays another for the same request, AAPKE LAWYER is not responsible for the additional payment.',
        ]),
      ],
    );
  }
}
