import 'package:flutter/material.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';

import 'app.dart';
import 'firebase_options.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  const useDebugAppCheck = bool.fromEnvironment('USE_APP_CHECK_DEBUG');
  await FirebaseAppCheck.instance.activate(
    providerAndroid: useDebugAppCheck
        ? const AndroidDebugProvider()
        : const AndroidPlayIntegrityProvider(),
    providerApple: useDebugAppCheck
        ? const AppleDebugProvider()
        : const AppleAppAttestProvider(),
  );
  await NotificationService.initialize();
  runApp(const AapkeLawyerApp());
}
